--RptLap_Harian
select * from q_AbsenHarianDetil where TGL_MASUK >= '1/8/2016' and TGL_MASUK <= '1/8/2016' order by KODE_UNIT, NIP, TGL_MASUK

